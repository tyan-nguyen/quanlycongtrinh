<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;port=3306;dbname=qlvt_3',
    'username' => 'root',
    'password' => '',
    'charset' => 'utf8',
];
