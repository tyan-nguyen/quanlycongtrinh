<?php
namespace webvimark\modules\UserManagement\models\rbacDB\search;

class RoleSearch extends AbstractItemSearch
{
	const ITEM_TYPE = self::TYPE_ROLE;
}